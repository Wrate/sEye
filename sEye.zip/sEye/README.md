# sEye — See Your Environment
Cuaca live (Open-Meteo, tanpa API key). Jalankan lewat server (Vercel / `npx serve`), bukan file://. GPS dan service worker butuh HTTPS atau localhost.
- Alur: GPS → koordinat → reverse geocoding (BigDataCloud) → Open-Meteo forecast → Open-Meteo air quality → normalisasi → UI.
- Ganti provider: `js/weather.js` (`real()`), `js/air-quality.js`, `js/location.js` (`searchCity`, `reverse`). Bentuk data lihat `mock()`.
- Demo mode hanya dari Settings → Data source → Demo (banner 🟡 muncul). Jika API gagal, UI menampilkan error, bukan data palsu. Data cache asli tampil dengan label offline.
- Radar/Map: DEMO animation (belum ada provider radar).
