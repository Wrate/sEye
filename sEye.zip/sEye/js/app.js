/* Controller: GPS → koordinat → cuaca → udara → normalisasi → UI. */
(function (S) {
  const $ = id => document.getElementById(id), P = S.P, W = S.W, ck = l => 'cache_' + l.lat.toFixed(2) + '_' + l.lon.toFixed(2);
  let cur = P('last', null), busy = false, tm;

  async function load(loc, quiet) {
    if (busy) return; busy = true; cur = loc; W('last', loc); if (!quiet || !S.st.data) S.setLoading(true);
    try {
      const [d, a] = await Promise.all([S.fetchWeather(loc), S.fetchAir(loc).catch(() => null)]);
      S.st.data = d; S.st.air = a; if (!d.mock) W(ck(loc), { d, a }); S.addRecent(loc); S.render();
    } catch (e) {
      const c = !S.demoMode() && P(ck(loc), null);
      if (c) { c.d.stale = true; S.st.data = c.d; S.st.air = c.a; S.render(); } else S.showError(navigator.onLine ? 'api' : 'offline');
    } finally { busy = false; }
  }
  async function gps() {
    S.setLoading(true);
    try { const g = await S.geolocate(); const r = await S.reverse(g.lat, g.lon); busy = false; await load({ ...g, ...r }); }
    catch (e) { busy = false; if (cur) { load(cur); } else S.showError(e.message === 'geo-denied' ? 'denied' : 'gps'); }
  }
  S.onPick = l => load(l);
  S.retry = () => cur ? load(cur) : gps();
  S.schedule = () => { clearInterval(tm); const m = P('refresh', 15); if (m > 0) tm = setInterval(() => cur && load(cur, true), m * 6e4); };

  $('gpsBtn').onclick = gps; $('searchBtn').onclick = S.openSearch; $('refreshBtn').onclick = () => S.retry();
  $('err').onclick = e => { const a = e.target.dataset.a; if (a === 'retry') S.retry(); if (a === 'search') S.openSearch(); };
  document.querySelector('.scrim').onclick = S.closeSheet;
  $('nav').onclick = e => { const b = e.target.closest('button'); if (b) S.view(b.dataset.v); };
  $('favs').onclick = e => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.fav) { S.toggleFav(S.st.data.loc); S.render(); } else load(S.favs()[b.dataset.i]); };
  $('v-set').onclick = e => {
    if (e.target.id === 'inst' && S.dip) { S.dip.prompt(); return; }
    const b = e.target.closest('.seg button'); if (!b) return; const k = b.parentNode.dataset.k, v = b.dataset.v;
    W(k, k === 'refresh' ? +v : k === 'auto' ? v === '1' : v);
    if (k === 'theme') S.setTheme(); if (k === 'anim') { S.setAnim(); } if (k === 'refresh') S.schedule();
    if (k === 'mode') { S.st.data = null; S.retry(); } else S.render();
  };
  addEventListener('beforeinstallprompt', e => { e.preventDefault(); S.dip = e; });
  addEventListener('online', () => S.retry());
  document.addEventListener('visibilitychange', () => { const d = S.st.data; if (!document.hidden && d && Date.now() - d.fetched > Math.max(5, P('refresh', 15)) * 6e4) load(cur, true); });
  setInterval(S.tickUpd, 3e4);

  let y0 = null; // pull-to-refresh
  addEventListener('touchstart', e => { y0 = scrollY === 0 && document.getElementById('v-home').classList.contains('on') ? e.touches[0].clientY : null; }, { passive: true });
  addEventListener('touchmove', e => { if (y0 !== null) $('ptr').classList.toggle('on', e.touches[0].clientY - y0 > 80); }, { passive: true });
  addEventListener('touchend', e => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 80) S.retry(); $('ptr').classList.remove('on'); y0 = null; });

  S.setTheme(); S.setAnim(); S.schedule();
  if (P('auto', true) || !cur) gps(); else load(cur);
  if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
})(window.SE = window.SE || {});
