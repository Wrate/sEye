/* Location adapter: GPS → reverse geocoding, pencarian kota, favorit, recent. */
(function (S) {
  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  S.store = { load, save };
  const CITIES = [['Palangka Raya', 'Indonesia', -2.21, 113.92], ['Jakarta', 'Indonesia', -6.2, 106.85], ['Singapore', 'Singapore', 1.35, 103.82], ['Tokyo', 'Japan', 35.68, 139.69]]
    .map(c => ({ name: c[0], country: c[1], lat: c[2], lon: c[3] }));
  S.searchCity = async q => {
    q = q.trim(); if (q.length < 2) return [];
    if (S.demoMode()) return CITIES.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
    const j = await S.jf(`${S.CFG.GEO_URL}?name=${encodeURIComponent(q)}&count=6&language=en`);
    return (j.results || []).map(x => ({ name: x.name, country: x.country || '', lat: x.latitude, lon: x.longitude }));
  };
  S.geolocate = () => new Promise((ok, no) => {
    if (!navigator.geolocation) return no(new Error('geo-unsupported'));
    navigator.geolocation.getCurrentPosition(p => ok({ lat: p.coords.latitude, lon: p.coords.longitude }),
      e => no(new Error(e.code === 1 ? 'geo-denied' : 'geo-fail')), { timeout: 12000, maximumAge: 3e5, enableHighAccuracy: false });
  });
  S.reverse = async (lat, lon) => { // nama kota nyata; fallback ke koordinat (bukan "Lokasi saya")
    try {
      const j = await S.jf(`${S.CFG.REV_URL}?latitude=${lat}&longitude=${lon}&localityLanguage=en`);
      const n = j.city || j.locality || j.principalSubdivision; if (n) return { name: n, country: j.countryName || '' };
    } catch (e) {}
    return { name: `${lat.toFixed(2)}, ${lon.toFixed(2)}`, country: '' };
  };
  const same = (a, b) => Math.abs(a.lat - b.lat) < .05 && Math.abs(a.lon - b.lon) < .05;
  S.favs = () => load('se_favs', []);
  S.isFav = l => S.favs().some(f => same(f, l));
  S.toggleFav = l => save('se_favs', S.isFav(l) ? S.favs().filter(f => !same(f, l)) : [...S.favs(), { name: l.name, country: l.country, lat: l.lat, lon: l.lon }]);
  S.recents = () => load('se_recent', []);
  S.addRecent = l => save('se_recent', [{ name: l.name, country: l.country, lat: l.lat, lon: l.lon }, ...S.recents().filter(r => !same(r, l))].slice(0, 5));
})(window.SE = window.SE || {});
