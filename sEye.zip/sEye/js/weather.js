/* Weather adapter. Default = LIVE (Open-Meteo, tanpa API key). Demo hanya jika dipilih di Settings. */
(function (S) {
  S.CFG = {
    FORECAST_URL: 'https://api.open-meteo.com/v1/forecast',
    AIR_URL: 'https://air-quality-api.open-meteo.com/v1/air-quality',
    GEO_URL: 'https://geocoding-api.open-meteo.com/v1/search',
    REV_URL: 'https://api.bigdatacloud.net/data/reverse-geocode-client'
  };
  S.demo = 0;
  S.demoMode = () => S.store.load('se_mode', 'live') === 'demo';
  S.jf = async u => {
    const c = new AbortController(), t = setTimeout(() => c.abort(), 12000);
    try { const r = await fetch(u, { signal: c.signal }); if (!r.ok) throw new Error('http ' + r.status); return await r.json(); }
    finally { clearTimeout(t); }
  };
  S.wmo = c => c === 0 ? ['☀️', 'Clear sky'] : c === 1 ? ['🌤️', 'Mostly clear'] : c === 2 ? ['⛅', 'Partly cloudy'] : c === 3 ? ['☁️', 'Overcast']
    : c < 50 ? ['🌫️', 'Fog'] : c < 60 ? ['🌦️', 'Drizzle'] : c < 70 ? ['🌧️', c >= 66 ? 'Freezing rain' : c === 65 ? 'Heavy rain' : c === 63 ? 'Rain' : 'Light rain']
    : c < 80 ? ['❄️', 'Snow'] : c < 85 ? ['🌧️', c === 82 ? 'Heavy showers' : 'Showers'] : c < 90 ? ['❄️', 'Snow showers'] : ['⛈️', 'Thunderstorm'];
  const p2 = n => String(n).padStart(2, '0');
  const iso = d => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}T${p2(d.getHours())}:${p2(d.getMinutes())}`;

  function mock(loc) { // hanya untuk DEMO MODE
    const h = Math.abs([...loc.name].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7) + S.demo), sc = h % 4;
    const code = [3, 63, 95, 0][sc], base = 26 + h % 6, now = new Date(), wet = sc === 1 || sc === 2, uvm = [6, 3, 2, 9][sc];
    const hourly = Array.from({ length: 24 }, (_, i) => { const d = new Date(now.getTime() + i * 36e5); d.setMinutes(0);
      return { t: iso(d), temp: base + Math.round(3 * Math.sin((d.getHours() - 9) / 24 * 6.28)), code: i % 5 === 4 ? 3 : code,
        pop: wet ? Math.max(20, 85 - i * 3) : 10 + (i % 4) * 5, mm: wet ? +Math.max(0, 3 - i * .1).toFixed(1) : 0, wind: 10 + h % 20 + (i % 6) * 3 }; });
    const day = Array.from({ length: 24 }, (_, k) => { const f = Math.max(0, Math.sin((k - 6) / 12 * Math.PI)); return { h: k, uv: +(uvm * f).toFixed(1), solar: Math.round(900 * f * (wet ? .35 : 1)) }; });
    const dn = day[now.getHours()];
    const daily = Array.from({ length: 7 }, (_, i) => { const c = [code, 2, 63, 0, 3, 61, 1][i]; return { date: iso(new Date(now.getTime() + i * 864e5)).slice(0, 10), code: c, max: base + 3 - i % 3, min: base - 4, pop: c > 50 ? 70 : 15, mm: c > 50 ? 8 : 0 }; });
    return { mock: true, loc, local: iso(now), hourly, daily, day, sun: { rise: '06:00', set: '18:00' },
      cur: { temp: base, feels: base + 3, code, humidity: 60 + h % 30, wind: 8 + h % 40, vis: 10, pressure: 1008, uv: dn.uv, solar: dn.solar } };
  }

  async function real(loc) {
    const q = `latitude=${loc.lat}&longitude=${loc.lon}&timezone=auto&forecast_days=7`
      + '&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,surface_pressure'
      + '&hourly=temperature_2m,weather_code,precipitation_probability,precipitation,visibility,uv_index,shortwave_radiation,wind_speed_10m'
      + '&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max,precipitation_sum';
    const j = await S.jf(`${S.CFG.FORECAST_URL}?${q}`), c = j.current, H = j.hourly, D = j.daily;
    if (!c || !H || !D || c.temperature_2m == null) throw new Error('bad-data');
    let i = H.time.findIndex(t => t >= c.time.slice(0, 13)); if (i < 0) i = 0;
    const hourly = H.time.slice(i, i + 24).map((t, k) => ({ t, temp: H.temperature_2m[i + k], code: H.weather_code[i + k],
      pop: H.precipitation_probability[i + k] || 0, mm: H.precipitation[i + k] || 0, wind: H.wind_speed_10m[i + k] || 0 }));
    const daily = D.time.map((d, k) => ({ date: d, code: D.weather_code[k], max: D.temperature_2m_max[k], min: D.temperature_2m_min[k],
      pop: D.precipitation_probability_max[k] || 0, mm: D.precipitation_sum[k] || 0 }));
    const dp = c.time.slice(0, 10), day = [];
    H.time.forEach((t, k) => { if (t.startsWith(dp)) day.push({ h: +t.slice(11, 13), uv: H.uv_index[k] ?? 0, solar: H.shortwave_radiation[k] ?? 0 }); });
    return { mock: false, loc: { ...loc, tz: j.timezone }, local: c.time, hourly, daily, day,
      sun: { rise: D.sunrise[0].slice(11), set: D.sunset[0].slice(11) },
      cur: { temp: c.temperature_2m, feels: c.apparent_temperature, code: c.weather_code, humidity: c.relative_humidity_2m, wind: c.wind_speed_10m,
        vis: (H.visibility[i] ?? 10000) / 1000, pressure: c.surface_pressure, uv: H.uv_index[i] ?? 0, solar: H.shortwave_radiation[i] ?? null } };
  }

  S.fetchWeather = async loc => {
    const d = S.demoMode() ? mock(loc) : await real(loc);
    const soon = d.hourly.slice(0, 6), wet = soon.find(h => h.pop >= 50);
    d.rain = { prob: Math.max(...soon.map(h => h.pop)), mm: +soon.reduce((a, h) => a + h.mm, 0).toFixed(1), when: wet ? wet.t.slice(11, 16) : null };
    d.fetched = Date.now(); d.source = d.mock ? 'DEMO' : 'Open-Meteo';
    return d;
  };
})(window.SE = window.SE || {});
