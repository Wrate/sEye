/* Air quality adapter (Open-Meteo Air Quality). Mengembalikan {aqi,pm25,pm10,co,no2,o3} atau null jika tidak ada. */
(function (S) {
  S.fetchAir = async loc => {
    if (S.demoMode()) {
      const aqi = [42, 78, 25, 120, 55][Math.abs([...loc.name].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 3) + S.demo) % 5];
      return { mock: true, aqi, pm25: aqi * .35, pm10: aqi * .6, co: 180 + aqi, no2: 8 + aqi / 10, o3: 40 + aqi / 3 };
    }
    const j = await S.jf(`${S.CFG.AIR_URL}?latitude=${loc.lat}&longitude=${loc.lon}&current=us_aqi,pm2_5,pm10,carbon_monoxide,nitrogen_dioxide,ozone`);
    const c = j.current; if (!c || c.us_aqi == null) return null;
    return { mock: false, aqi: c.us_aqi, pm25: c.pm2_5, pm10: c.pm10, co: c.carbon_monoxide, no2: c.nitrogen_dioxide, o3: c.ozone };
  };
  S.aqiLevel = a => a <= 50 ? ['GOOD', '#4ade80', 'Air quality is good for outdoor activity.']
    : a <= 100 ? ['MODERATE', '#facc15', 'Acceptable; sensitive groups should pay attention.']
    : a <= 150 ? ['UNHEALTHY (SENSITIVE)', '#fb923c', 'Limit heavy outdoor activity if you are sensitive.']
    : a <= 200 ? ['UNHEALTHY', '#f87171', 'Reduce prolonged outdoor activity.'] : ['VERY UNHEALTHY', '#c084fc', 'Avoid outdoor activity where possible.'];
})(window.SE = window.SE || {});
