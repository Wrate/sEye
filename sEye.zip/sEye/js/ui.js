/* UI: scene, hero, sections, views, sheet, settings. */
(function (S) {
  const $ = id => document.getElementById(id);
  const P = S.P = (k, d) => S.store.load('se_' + k, d), W = S.W = (k, v) => S.store.save('se_' + k, v);
  const st = S.st = { data: null, air: null };
  const RM = () => P('anim', 'full') === 'reduced' || matchMedia('(prefers-reduced-motion:reduce)').matches;
  const T = c => Math.round(P('unit', 'C') === 'C' ? c : c * 9 / 5 + 32);
  const p2 = n => String(n).padStart(2, '0'), mins = s => +s.slice(0, 2) * 60 + +s.slice(3, 5), esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const sm = p => p.map((q, i) => i ? `Q${p[i - 1][0]} ${p[i - 1][1]} ${(p[i - 1][0] + q[0]) / 2} ${(p[i - 1][1] + q[1]) / 2}` : `M${q[0]} ${q[1]}`).join('') + `L${p.at(-1)[0]} ${p.at(-1)[1]}`;

  function count(el, to) {
    const from = +el.dataset.v || 0; el.dataset.v = to; if (RM()) { el.textContent = to; return; }
    const t0 = performance.now();
    (function f(t) { const p = Math.min(1, (t - t0) / 800); el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(f); })(t0);
  }
  const uvL = u => u < 3 ? ['LOW', '#4ade80', 'No special protection needed for most people.'] : u < 6 ? ['MODERATE', '#facc15', 'Consider sunscreen and a hat if outside for long.']
    : u < 8 ? ['HIGH', '#fb923c', 'Use sunscreen, a hat, and seek shade.'] : u < 11 ? ['VERY HIGH', '#f87171', 'Use SPF 30+, cover up, avoid midday sun.'] : ['EXTREME', '#c084fc', 'Avoid direct sun; use full protection.'];

  /* ---- Scene ---- */
  S.sceneFor = (c, hm, sun) => {
    const n = mins(hm), r = mins(sun.rise), s = mins(sun.set);
    if (c >= 95) return 'storm'; if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
    if (n < r - 20 || n > s + 40) return 'night'; if (Math.abs(n - s) < 50 || Math.abs(n - r) < 30) return 'sunset';
    return [2, 3, 45, 48].includes(c) ? 'cloud' : 'clear';
  };
  const cv = $('fx'), cx = cv.getContext('2d'); let raf = 0, lt = 0, kind = '';
  function fx(sc) {
    cancelAnimationFrame(raf); clearInterval(lt); kind = sc; cx.clearRect(0, 0, cv.width, cv.height);
    if (RM() || sc === 'cloud') return;
    cv.width = innerWidth; cv.height = innerHeight; const w = cv.width, h = cv.height, rain = sc === 'rain' || sc === 'storm', sl = sc === 'storm' ? 3 : .8; let rp = [];
    const ps = Array.from({ length: rain ? 60 : sc === 'night' ? 45 : 18 }, () => ({ x: Math.random() * w, y: Math.random() * h, s: rain ? 9 + Math.random() * 6 : Math.random() * 1.5 + .5, a: Math.random() * 6 }));
    (function loop() {
      cx.clearRect(0, 0, w, h);
      if (rain) {
        cx.strokeStyle = 'rgba(210,225,255,.5)'; cx.beginPath();
        ps.forEach(p => { cx.moveTo(p.x, p.y); cx.lineTo(p.x - sl * 2, p.y + p.s * 1.6); p.y += p.s; p.x -= sl;
          if (p.y > h) { if (rp.length < 6) rp.push({ x: p.x, y: h - 30 - Math.random() * 80, r: 0 }); p.y = -10; p.x = Math.random() * w * 1.2; } });
        cx.stroke(); rp = rp.filter(r => r.r < 22); cx.strokeStyle = 'rgba(210,225,255,.3)';
        rp.forEach(r => { r.r += .6; cx.beginPath(); cx.ellipse(r.x, r.y, r.r, r.r / 3, 0, 0, 6.3); cx.stroke(); });
      } else {
        cx.fillStyle = '#fff';
        ps.forEach(p => { p.a += .02;
          if (sc === 'night') { cx.globalAlpha = .4 + .6 * Math.abs(Math.sin(p.a)); cx.fillRect(p.x, p.y * .7, p.s, p.s); }
          else { p.y -= .15; p.x += Math.sin(p.a) * .3; if (p.y < 0) p.y = h; cx.globalAlpha = .25; cx.beginPath(); cx.arc(p.x, p.y, p.s * 1.5, 0, 6.3); cx.fill(); } });
        cx.globalAlpha = 1;
      }
      raf = requestAnimationFrame(loop);
    })();
    if (sc === 'storm') lt = setInterval(() => { if (Math.random() < .5) { const f = $('flash'); f.classList.remove('on'); void f.offsetWidth; f.classList.add('on'); } }, 6000);
  }
  S.applyScene = sc => { if (document.body.dataset.scene === sc) return; const k = $('sky'); k.classList.add('fade');
    setTimeout(() => { document.body.dataset.scene = sc; k.classList.remove('fade'); fx(sc); }, RM() ? 0 : 250); };
  document.addEventListener('visibilitychange', () => document.hidden ? cancelAnimationFrame(raf) : fx(kind));

  /* ---- Sheet / banner / errors ---- */
  S.sheet = html => { $('sheetBody').innerHTML = html; $('sheet').hidden = false; };
  S.closeSheet = () => { $('sheet').hidden = true; };
  S.setLoading = on => document.body.classList.toggle('loading', on);
  const E = { offline: ['📡', 'No internet', 'Check your connection and try again.'], denied: ['📍', 'Location access denied', 'Allow location access in your browser, or search for a city.'],
    gps: ['📍', 'Unable to get location', 'Try again, or search for a city.'], api: ['☁️', 'Unable to get live weather', 'Live weather is unavailable right now. Try again in a moment.'], none: ['🔎', 'No weather data', 'No data found for this location.'] };
  S.showError = k => { const e = E[k] || E.api; S.setLoading(false); $('err').innerHTML = `<em>${e[0]}</em><h3>${e[1]}</h3><p>${e[2]}</p><button class="btn" data-a="retry">Retry</button><button class="btn" data-a="search">Search city</button>`; $('err').hidden = false; if (!st.data) $('v-home').hidden = true; };
  const ago = ms => { const m = Math.round((Date.now() - ms) / 6e4); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : Math.floor(m / 60) + ' h ago'; };
  S.tickUpd = () => { const d = st.data; if (!d) return; $('upd').textContent = `${d.stale ? 'Offline · last updated' : 'Updated'} ${new Date(d.fetched).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })} · ${ago(d.fetched)}`; };

  /* ---- Computations ---- */
  const score = (d, a) => { const c = d.cur; let x = 0; const f = c.feels;
    x += f > 27 ? Math.min(35, (f - 27) * 4) : f < 18 ? Math.min(30, (18 - f) * 3) : 0; x += d.rain.prob * .4; x += c.uv >= 6 ? Math.min(24, (c.uv - 5) * 4) : 0;
    x += c.wind > 25 ? Math.min(15, (c.wind - 25) * .8) : 0; x += a && a.aqi > 50 ? Math.min(25, (a.aqi - 50) * .3) : 0; return Math.max(0, Math.round(100 - x)); };
  const summary = d => { const c = d.cur, R = d.rain, H = d.hourly.slice(0, 6); let s = `${S.wmo(c.code)[1]}, ${T(c.temp)}°.`;
    const cl = c.code < 2 && H.find(h => h.code >= 2 && h.code <= 3);
    s += R.when && R.prob >= 50 ? ` Rain is likely around ${R.when} (${R.prob}%).` : cl ? ` Cloud cover is increasing around ${cl.t.slice(11, 16)}.` : ' No significant rain expected in the next 6 hours.';
    const mx = Math.max(...H.map(h => h.temp)); if (mx > c.temp + 1) s += ` Temperature rises to ${T(mx)}°.`; return s; };
  const tip = (d, a) => { const c = d.cur; return c.uv >= 8 ? 'UV index cukup tinggi hari ini. Jika beraktivitas di luar, pertimbangkan perlindungan dari sinar UV.' : d.rain.prob >= 60 ? 'Kemungkinan hujan tinggi. Bawa payung atau jas hujan.'
    : c.temp >= 33 ? 'Suhu tinggi. Minum air yang cukup dan cari tempat teduh.' : a && a.aqi > 100 ? 'Kualitas udara kurang baik. Kurangi aktivitas berat di luar ruangan.' : c.wind >= 30 ? 'Angin cukup kencang. Amankan barang ringan di luar.' : 'Kondisi cukup stabil hari ini.'; };
  const insights = d => { const o = [], D = d.day, H = d.hourly, mu = D.reduce((a, x) => x.uv > a.uv ? x : a, D[0]);
    if (mu.uv >= 1) o.push(['☀️', `UV peaks at ${p2(mu.h)}:00`, `Peak UV today is ${mu.uv.toFixed(1)} (${uvL(mu.uv)[0]}). ${uvL(mu.uv)[2]}`]);
    if (d.rain.when) o.push(['🌧️', `Rain likely around ${d.rain.when}`, `Up to ${d.rain.prob}% chance in the next 6 hours, about ${d.rain.mm} mm.`]);
    const mw = H.reduce((a, x) => x.wind > a.wind ? x : a, H[0]); if (mw.wind >= 20) o.push(['🌬️', `Wind peaks at ${mw.t.slice(11, 16)}`, `Up to ${Math.round(mw.wind)} km/h.`]);
    const ss = H.find(x => x.t.slice(11, 13) >= d.sun.set.slice(0, 2)), la = H.at(-1);
    if (ss && la.temp < ss.temp - 1) o.push(['🌡️', 'Temperature drops after sunset', `From ${T(ss.temp)}° at sunset to ${T(la.temp)}° by ${la.t.slice(11, 16)}.`]);
    return o.length ? o : [['✅', 'Stable conditions', 'No significant changes expected in the next 24 hours.']]; };
  const alerts = d => { const o = [], H = d.hourly, r = l => `${l[0].t.slice(11, 16)}–${l.at(-1).t.slice(11, 16)}`;
    let l = H.filter(h => h.pop >= 80 && h.mm >= 2.5); if (l.length) o.push({ ic: '🌧️', t: 'Heavy Rain', when: r(l), lv: 2 });
    l = H.filter(h => h.code >= 95); if (l.length) o.push({ ic: '⛈️', t: 'Thunderstorm', when: r(l), lv: 3 });
    l = H.filter(h => h.wind >= 40); if (l.length) o.push({ ic: '🌬️', t: 'Strong Wind', when: r(l), lv: 2 });
    const u = d.day.filter(x => x.uv >= 8); if (u.length) o.push({ ic: '☀️', t: u.some(x => x.uv >= 11) ? 'Extreme UV' : 'High UV', when: `Today ${p2(u[0].h)}:00–${p2(u.at(-1).h + 1)}:00`, lv: u.some(x => x.uv >= 11) ? 3 : 1 });
    return o; };
  const LV = ['', '#facc15', '#fb923c', '#f87171'];

  /* ---- Section builders ---- */
  const radar = (id, big, c) => { const g = (n, col) => `<radialGradient id="${id}${n}"><stop offset="0" stop-color="${col}" stop-opacity=".85"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></radialGradient>`;
    return `<div class="radar ${big ? 'big' : ''}"><svg viewBox="0 0 300 200" preserveAspectRatio="xMidYMid slice"><defs>${g(1, '#4ade80')}${g(2, '#facc15')}${g(3, '#f87171')}</defs>
      <g stroke="rgba(255,255,255,.14)">${[50, 100, 150, 200, 250].map(x => `<path d="M${x} 0V200"/>`).join('')}${[50, 100, 150].map(y => `<path d="M0 ${y}H300"/>`).join('')}</g>
      <ellipse class="rb" cx="60" cy="60" rx="55" ry="32" fill="url(#${id}1)"/><ellipse class="rb" cx="90" cy="120" rx="45" ry="28" fill="url(#${id}2)"/><ellipse class="rb" cx="40" cy="100" rx="28" ry="18" fill="url(#${id}3)"/>
      <circle cx="150" cy="100" r="6" fill="#fff"/><circle class="pulse" cx="150" cy="100" r="6" fill="none" stroke="#fff" stroke-width="2"/>${big ? `<text x="160" y="92" fill="#fff" font-size="12">${T(c.temp)}°</text>` : ''}</svg>
      <span class="demo">🟡 DEMO — not real radar data</span></div>`; };

  function hourlySec(d) { const H = d.hourly, n = H.length, w = 320, h = 90, ts = H.map(x => T(x.temp)), mn = Math.min(...ts), mx = Math.max(...ts);
    const X = i => 12 + i * (w - 24) / (n - 1), Y = v => 14 + (mx - v) / (mx - mn || 1) * (h - 34), pts = ts.map((v, i) => [X(i), Y(v)]);
    return `<div class="panel rv"><h3>Hourly · drag the timeline</h3><div class="hs" id="hsel"></div>
      <div class="chart"><svg viewBox="0 0 ${w} ${h}"><path class="ln" pathLength="1" d="${sm(pts)}"/><circle id="tdot" r="6" style="cx:${pts[0][0]}px;cy:${pts[0][1]}px"/></svg></div>
      <input type="range" id="scrub" min="0" max="${n - 1}" value="0" aria-label="Hour"><div class="ticks">${[0, 6, 12, 18, 23].map(i => `<span>${i ? H[i].t.slice(11, 16) : 'Now'}</span>`).join('')}</div></div>`; }
  function hourSel(i) { const d = st.data, h = d.hourly[i], n = d.hourly.length, w = 320, hh = 90, ts = d.hourly.map(x => T(x.temp)), mn = Math.min(...ts), mx = Math.max(...ts);
    $('hsel').innerHTML = `<em>${S.wmo(h.code)[0]}</em><div><b>${T(h.temp)}°</b><div class="small">${i ? h.t.slice(11, 16) : 'Now'} · ${S.wmo(h.code)[1]} · 🌧️ ${h.pop}%</div></div>`;
    const dot = $('tdot'); if (dot) { dot.style.cx = 12 + i * (w - 24) / (n - 1) + 'px'; dot.style.cy = 14 + (mx - T(h.temp)) / (mx - mn || 1) * (hh - 34) + 'px'; }
    S.applyScene(S.sceneFor(h.code, h.t.slice(11, 16), d.sun)); }

  function aqSec(a) { if (!a) return '<div class="panel rv"><h3>🌫️ Air Quality</h3><p class="small">Air quality data is unavailable for this location.</p></div>';
    const [l, c] = S.aqiLevel(a.aqi), f = v => v == null ? '–' : v.toFixed(0);
    return `<div class="panel rv tap" id="aq"><h3>🌫️ Air Quality</h3><div class="big">${Math.round(a.aqi)} <span class="lvl" style="color:${c}">${l}</span></div><div class="aqg"><i data-l="${Math.min(100, a.aqi / 300 * 100)}"></i></div>
      <div class="pol"><div><b>${f(a.pm25)}</b>PM2.5 µg/m³</div><div><b>${f(a.pm10)}</b>PM10 µg/m³</div><div><b>${f(a.o3)}</b>O₃ µg/m³</div></div></div>`; }
  function uvSec(c) { const [l, col] = uvL(c.uv);
    return `<div class="panel rv tap" id="uv"><h3>☀️ UV Index</h3><div class="gauge"><svg viewBox="0 0 160 100"><path class="trk" pathLength="100" d="M20 90A60 60 0 0 1 140 90"/><path class="arc" pathLength="100" d="M20 90A60 60 0 0 1 140 90" style="--p:${Math.min(100, c.uv / 12 * 100)};stroke:${col}"/></svg>
      <div class="cen"><b>${Math.round(c.uv)}</b><span style="color:${col}">${l}</span></div></div><p class="small" style="text-align:center;margin-top:8px">Scale 0 – 11+</p></div>`; }
  function solarSec(d) { const D = d.day, mx = Math.max(1, ...D.map(x => x.solar)), w = 320, h = 100, pts = D.map((x, i) => [8 + i * (w - 16) / 23, 8 + (1 - x.solar / mx) * (h - 26)]), now = +d.local.slice(11, 13), s = d.cur.solar;
    return `<div class="panel rv"><h3>Solar Radiation</h3><div class="big">${s == null ? '–' : Math.round(s)} <span class="small">W/m²</span></div><div class="chart"><svg viewBox="0 0 ${w} ${h}"><path class="ar" d="${sm(pts)}L${w - 8} ${h - 18}L8 ${h - 18}Z"/><path class="ln" pathLength="1" d="${sm(pts)}"/><circle cx="${pts[now][0]}" cy="${pts[now][1]}" r="5" fill="#ffd166"/></svg></div>
      <div class="ticks"><span>Morning</span><span>Noon</span><span>Afternoon</span><span>Sunset</span></div><p class="small" style="margin-top:8px">Solar radiation is energy from the sun (W/m²), different from the UV index.</p></div>`; }
  function sunSec(d) { const n = mins(d.local.slice(11)), r = mins(d.sun.rise), s = mins(d.sun.set), p = Math.max(0, Math.min(1, (n - r) / (s - r))), a = Math.PI * p;
    return `<div class="panel rv"><h3>Sun Path</h3><div class="sunp"><svg viewBox="0 0 200 110"><path d="M10 95A90 80 0 0 1 190 95" fill="none" stroke="rgba(255,255,255,.35)" stroke-dasharray="3 4"/><path d="M10 95H190" stroke="rgba(255,255,255,.3)"/><circle cx="${100 - 90 * Math.cos(a)}" cy="${95 - 80 * Math.sin(a)}" r="8" fill="#ffd166"/></svg></div>
      <div class="ticks"><span>🌅 Sunrise ${d.sun.rise}</span><span>🌇 Sunset ${d.sun.set}</span></div></div>`; }

  S.render = () => { const d = st.data, a = st.air; if (!d) return; const c = d.cur, [ico, txt] = S.wmo(c.code), sc = score(d, a), al = alerts(d);
    document.body.classList.remove('loading'); $('err').hidden = true; $('v-home').hidden = false;
    S.applyScene(S.sceneFor(c.code, d.local.slice(11, 16), d.sun));
    $('place').textContent = d.loc.name + (d.loc.country ? ', ' + d.loc.country : '');
    $('date').textContent = new Date(d.local.slice(0, 10) + 'T12:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' }) + ' · ' + d.local.slice(11, 16);
    count($('temp'), T(c.temp)); const cd = $('cond'), nt = `${ico} ${txt}`; if (cd.textContent !== nt) { cd.textContent = nt; cd.classList.remove('sw'); void cd.offsetWidth; cd.classList.add('sw'); }
    $('feels').textContent = `Feels like ${T(c.feels)}°`; $('hl').textContent = `H ${T(d.daily[0].max)}°   L ${T(d.daily[0].min)}°`; S.tickUpd();
    const b = $('banner'); b.hidden = !(d.mock || d.stale); b.textContent = d.mock ? '🟡 DEMO MODE — sample data, not real weather' : d.stale ? `Offline — showing last saved data from ${new Date(d.fetched).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` : '';
    const dl = c.feels - c.temp, days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $('stack').innerHTML = al.slice(0, 2).map(x => `<div class="alert">⚠️ <b>${x.t}</b> · ${x.when}</div>`).join('')
      + `<div class="panel rv"><h3>What's happening</h3><p>${summary(d)}</p><p class="small" style="margin-top:8px">Generated automatically from weather data.</p><p class="small" style="margin-top:8px">💡 ${tip(d, a)}</p></div>`
      + `<div class="panel rv tap" id="os"><h3>Outdoor Score</h3><div class="big">${sc}<span class="small"> / 100</span></div><p class="lvl" style="margin-top:6px">${sc >= 75 ? '🌤️ Good conditions' : sc >= 50 ? '⛅ Fair conditions' : '🌧️ Consider staying indoors'}</p><p class="small" style="margin-top:6px">Based on temperature, rain, UV, wind and air quality. Not health advice.</p></div>`
      + `<div class="panel rv"><h3>Feels like</h3><div class="fl"><div><b>${T(c.temp)}°</b><span>Actual</span></div><span style="font-size:26px">→</span><div><b>${T(c.feels)}°</b><span>Feels like</span></div></div>
        <div class="tags"><span>💧 Humidity ${Math.round(c.humidity)}% ${c.humidity >= 70 ? '↑ makes it feel warmer' : c.humidity <= 40 ? '↓ dry air' : '· comfortable'}</span><span>🌬️ Wind ${Math.round(c.wind)} km/h ${c.wind >= 15 ? '↓ cools the air on skin' : '· little cooling'}</span><span>🌡️ ${Math.abs(dl) < .5 ? 'Feels about the same' : `Feels ${Math.abs(Math.round(dl))}° ${dl > 0 ? 'warmer' : 'cooler'}`}</span></div></div>`
      + hourlySec(d) + aqSec(a) + `<div class="two">${uvSec(c)}<div class="panel rv"><h3>Rain</h3><div class="big">${d.rain.prob}%</div><p class="small" style="margin-top:8px">${d.rain.mm} mm · ${d.rain.when ? 'around ' + d.rain.when : 'none expected soon'}</p></div></div>`
      + solarSec(d) + sunSec(d) + `<div class="panel rv"><h3>Radar</h3>${radar('rh', 0, c)}</div>`
      + `<div class="panel rv"><h3>7-Day Forecast</h3>${d.daily.map((x, i) => `<div class="day"><span>${i ? days[new Date(x.date + 'T12:00').getDay()] : 'Today'}</span><em>${S.wmo(x.code)[0]}</em><span>${T(x.max)}° <span class="dim">/ ${T(x.min)}°</span></span></div>`).join('')}</div>`;
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); e.target.querySelectorAll('.aqg i').forEach(i => i.style.left = i.dataset.l + '%'); io.unobserve(e.target); } }), { threshold: .12 });
    document.querySelectorAll('.rv').forEach(x => io.observe(x)); hourSel(0);
    $('scrub').oninput = e => hourSel(+e.target.value);
    if ($('aq')) $('aq').onclick = () => { const [l, col, ds] = S.aqiLevel(a.aqi), f = v => v == null ? '–' : v.toFixed(1);
      S.sheet(`<h3>Air Quality</h3><div class="big">${Math.round(a.aqi)} <span class="lvl" style="color:${col}">${l}</span></div><p class="small" style="margin:10px 0">${ds}</p>${[['PM2.5', a.pm25], ['PM10', a.pm10], ['O₃', a.o3], ['NO₂', a.no2], ['CO', a.co]].map(r => `<div class="row"><span>${r[0]}</span><b>${f(r[1])} µg/m³</b></div>`).join('')}`); };
    $('uv').onclick = () => { const [l, col, ds] = uvL(c.uv); S.sheet(`<h3>UV Index</h3><div class="big">${Math.round(c.uv)} <span class="lvl" style="color:${col}">${l}</span></div><p class="small" style="margin:10px 0">${ds}</p><div class="row"><span>Solar radiation</span><b>${c.solar == null ? 'n/a' : Math.round(c.solar) + ' W/m²'}</b></div>`); };
    $('os').onclick = () => S.sheet(`<h3>Outdoor Score ${sc}/100</h3><p class="small">Score starts at 100 and is reduced by uncomfortable temperature, rain probability, high UV, strong wind, and poor air quality.</p>`);
    const cur = d.loc; $('favs').innerHTML = S.favs().map((f, i) => `<button class="chip" data-i="${i}">📍 ${esc(f.name)}</button>`).join('') + `<button class="chip" data-fav="1">${S.isFav(cur) ? '★ Saved' : '☆ Save location'}</button>`;
    renderIns(d, al); renderMap(d); renderSet(); };

  function renderIns(d, al) { $('v-ins').innerHTML = `<h1 class="pg">Insights</h1>${insights(d).map((x, i) => `<div class="panel tap al" data-in="${i}"><em>${x[0]}</em><div><b>${x[1]}</b><span class="small">Tap for details</span></div></div>`).join('')}
    <h1 class="pg">Weather Alerts</h1>${al.length ? al.map(x => `<div class="panel al"><em>${x.ic}</em><div><b>${x.t}</b><span class="small">${x.when}</span></div><i class="dot" style="background:${LV[x.lv]}"></i></div>`).join('') : '<div class="panel"><p>✅ No active alerts for the next 24 hours.</p></div>'}`;
    $('v-ins').onclick = e => { const r = e.target.closest('[data-in]'); if (r) { const x = insights(d)[r.dataset.in]; S.sheet(`<h3>${x[0]} ${x[1]}</h3><p class="small" style="margin-top:10px">${x[2]}</p>`); } }; }
  function renderMap(d) { $('v-map').innerHTML = `<h1 class="pg">Map</h1><div class="panel">${radar('rm', 1, d.cur)}<p class="small" style="margin-top:10px">Demo animation only. Your location marker and temperature are real; rain areas are not. Live radar tiles need a radar provider.</p></div>`; }
  const seg = (k, o, cur) => `<div class="seg" data-k="${k}">${o.map(([v, l]) => `<button data-v="${v}" class="${String(v) === String(cur) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  function renderSet() { const d = st.data;
    $('v-set').innerHTML = `<h1 class="pg">Settings</h1><div class="panel"><h3>Appearance</h3>${seg('theme', [['light', 'Light'], ['dark', 'Dark'], ['auto', 'Auto']], P('theme', 'auto'))}</div>
      <div class="panel"><h3>Temperature</h3>${seg('unit', [['C', 'Celsius'], ['F', 'Fahrenheit']], P('unit', 'C'))}</div>
      <div class="panel"><h3>Data refresh</h3>${seg('refresh', [[0, 'Off'], [5, '5 min'], [15, '15 min'], [30, '30 min']], P('refresh', 15))}</div>
      <div class="panel"><h3>Animation</h3>${seg('anim', [['full', 'Full'], ['reduced', 'Reduced']], P('anim', 'full'))}</div>
      <div class="panel"><h3>Location</h3>${seg('auto', [[1, 'Auto-detect on open'], [0, 'Manual']], P('auto', true) ? 1 : 0)}</div>
      <div class="panel"><h3>Data source</h3>${seg('mode', [['live', 'Live'], ['demo', '🟡 Demo']], P('mode', 'live'))}<p class="small" style="margin-top:10px">${d ? `${d.source}${d.mock ? ' (sample data)' : ' (live)'} · fetched ${new Date(d.fetched).toLocaleTimeString('en-GB')} · ${d.loc.lat.toFixed(2)}, ${d.loc.lon.toFixed(2)}` : '–'}</p></div>
      <div class="panel">${S.dip ? '<button class="btn" id="inst">Install sEye</button>' : '<p class="small">To install, use “Add to Home screen” in your browser menu.</p>'}<p class="small" style="margin-top:8px">Weather alert notifications are not available yet.</p></div>`; }
  S.setTheme = () => { const t = P('theme', 'auto'); document.documentElement.dataset.theme = t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme:dark)').matches) ? 'dark' : 'light'; };
  S.setAnim = () => document.documentElement.classList.toggle('rm', RM());

  /* ---- Search (Spotlight) ---- */
  S.openSearch = () => { const row = (c, i, s) => `<div class="row sel" data-s="${s}" data-i="${i}" style="animation-delay:${i * 40}ms"><span>📍 ${esc(c.name)}</span><span class="small">${esc(c.country)}</span></div>`;
    const idle = () => { const r = S.recents(), f = S.favs(); return (f.length ? '<p class="small">Favorites</p>' + f.map((c, i) => row(c, i, 'f')).join('') : '') + (r.length ? '<p class="small" style="margin-top:12px">Recent</p>' + r.map((c, i) => row(c, i, 'r')).join('') : ''); };
    S.sheet(`<input id="q" placeholder="Search location…" autocomplete="off"><div id="res">${idle()}</div>`); const q = $('q'); q.focus(); let tm, list = [];
    q.oninput = () => { clearTimeout(tm); if (q.value.trim().length < 2) { $('res').innerHTML = idle(); return; } $('res').innerHTML = '<p class="small">Searching…</p>';
      tm = setTimeout(async () => { try { list = await S.searchCity(q.value); $('res').innerHTML = list.length ? list.map((c, i) => row(c, i, 's')).join('') : '<p class="small">No locations found.</p>'; }
        catch (e) { $('res').innerHTML = '<p class="small">Search failed. Check your connection.</p>'; } }, 300); };
    $('res').onclick = e => { const r = e.target.closest('[data-s]'); if (!r) return; const src = { f: S.favs(), r: S.recents(), s: list }[r.dataset.s]; S.closeSheet(); S.onPick(src[r.dataset.i]); }; };

  S.view = v => { document.querySelectorAll('.view').forEach(x => x.classList.toggle('on', x.id === 'v-' + v)); document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.v === v)); scrollTo({ top: 0 }); };
})(window.SE = window.SE || {});
